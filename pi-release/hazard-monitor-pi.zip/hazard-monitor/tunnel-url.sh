#!/usr/bin/env bash
# Prints the current public https://....trycloudflare.com URL of the Pi
# (it changes every time the Pi or the tunnel restarts).
SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
URL="$($SUDO journalctl -u hazard-tunnel -b -o cat --no-pager 2>/dev/null \
  | grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' | tail -1)"
[ -n "$URL" ] || exit 1
echo "$URL"
