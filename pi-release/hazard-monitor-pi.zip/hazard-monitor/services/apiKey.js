const crypto = require('crypto');

const digest = (s) => crypto.createHash('sha256').update(String(s)).digest();

// Rejects requests that don't carry the right key in the "x-api-key" header.
// The key lives in .env as API_KEY (setup.sh generates one).
const requireApiKey = (req, res, next) => {
  const expected = process.env.API_KEY;
  if (!expected) {
    return res.status(500).json({ error: 'API_KEY is not set in .env on the Pi' });
  }
  const given = req.get('x-api-key');
  if (!given || !crypto.timingSafeEqual(digest(given), digest(expected))) {
    return res.status(401).json({ error: 'Missing or wrong x-api-key header' });
  }
  next();
};

module.exports = { requireApiKey };
