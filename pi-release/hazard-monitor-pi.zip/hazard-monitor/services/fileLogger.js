const fs = require('fs');
const os = require('os');
const path = require('path');

// Every valid reading is also appended to a CSV file (default: ~/Downloads/received_data.csv)
// so the data can be opened in Excel even without MongoDB. Override with DATA_FILE in .env
const DATA_FILE = process.env.DATA_FILE || path.join(os.homedir(), 'Downloads', 'received_data.csv');

const COLUMNS = [
  'received_at', 'sender_ip', 'node_id',
  'water_level', 'soil_moisture', 'rain', 'temperature', 'humidity', 'tilt',
  'smoke', 'flame',
];

const csvCell = (v) => {
  if (v === undefined || v === null) return '';
  const s = String(v);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

// Appends are chained so the header is written once and lines never interleave
let queue = Promise.resolve();

const logReading = (data, senderIp) => {
  const row = {
    ...data,
    received_at: new Date().toISOString(),
    sender_ip: (senderIp || '').replace(/^::ffff:/, ''),
  };
  const line = COLUMNS.map((c) => csvCell(row[c])).join(',') + '\n';

  queue = queue
    .then(async () => {
      await fs.promises.mkdir(path.dirname(DATA_FILE), { recursive: true });
      const exists = await fs.promises.access(DATA_FILE).then(() => true, () => false);
      await fs.promises.appendFile(DATA_FILE, (exists ? '' : COLUMNS.join(',') + '\n') + line);
    })
    .catch((err) => console.error('Could not write to', DATA_FILE, '-', err.message));
  return queue;
};

module.exports = { logReading, DATA_FILE };
